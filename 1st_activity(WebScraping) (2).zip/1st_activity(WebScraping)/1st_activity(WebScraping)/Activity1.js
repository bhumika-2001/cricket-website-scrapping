// install minimist,axios,jsdom,excel4node,pdf-lib
// run as node Activity1.js --url=https://www.espncricinfo.com/series/icc-cricket-world-cup-2019-1144415/match-results --folder=WorldCup2k19

let minimist= require("minimist");
let args=minimist(process.argv);
let excel=require("excel4node");
let axios = require("axios");
let jsdom=require("jsdom");
let pdflib = require("pdf-lib");
let path=require("path");
let fs=require("fs");

let promise = axios.get(args.url);
promise.then(function(response){
    let html =response.data;
    let dom=new jsdom.JSDOM(html);
    let document=dom.window.document;

    let matchDivs = document.querySelectorAll("div.match-score-block");
    let matches =[];
    for(let i=0;i<matchDivs.length;i++)
    {
        let match={};
        let teamName = matchDivs[i].querySelectorAll("p.name");
        match.t1 = teamName[0].textContent;
        match.t2 = teamName[1].textContent;


        match.t1s="";
        match.t2s="";
        let scores = matchDivs[i].querySelectorAll("div.score-detail > span.score");
        if(scores.length==2)
        {
            match.t1s = scores[0].textContent;
            match.t2s = scores[1].textContent;
        }
        else if(scores.length == 1)
        {
            match.t1s = scores[0].textContent;
        }

        let res = matchDivs[i].querySelector("div.status-text > span");
        match.result = res.textContent;
        matches.push(match);
    }
    
    let teams=[];
    for(let i=0;i<matches.length;i++)
    {
        addTeams(matches[i],teams);
    }
    
    for(let i=0;i<matches.length;i++)
    {
        addMatchesToTeam(matches[i],teams);
    }
    //console.log(teams);
    createExcel(teams);
    createFoldersAndPDF(teams);

}).catch(function(err){
    console.log(err);
});

function addTeams(match,teams)
{
    let index = -1;
    for(let i=0;i<teams.length;i++)
    {
        if(teams[i].name == match.t1)
        {
            index =i;
            break;
        }
    }
    if(index == -1)
    {
        let team = {
            name : match.t1,
            matches:[]
        };
        teams.push(team);
    }

    let index1 = -1;
    for(let i=0;i<teams.length;i++)
    {
        if(teams[i].name == match.t2)
        {
            index1 =i;
            break;
        }
    }
    if(index1 == -1)
    {
        let team = {
            name : match.t2,
            matches : []
        };
        teams.push(team);
    }
}

function addMatchesToTeam(match,teams)
{
    let index1 = -1;
    for(let i=0;i<teams.length;i++)
    {
        if(teams[i].name ==  match.t1)
        {
            index1=i;
            break;
        }
    }

    let team1 = teams[index1];
    team1.matches.push({
        vs : match.t2,
        selfScore:match.t1s,
        opponentScore : match.t2s,
        result : match.result
    });

    let index2 = -1;
    for(let i=0;i<teams.length;i++)
    {
        if(teams[i].name ==  match.t2)
        {
            index2=i;
            break;
        }
    }

    let team2 = teams[index2];
    team2.matches.push({
        vs : match.t1,
        selfScore:match.t2s,
        opponentScore : match.t1s,
        result : match.result
    });
}

function createExcel(teams)
{
    let wb = new excel.Workbook();
    for(let i=0;i<teams.length;i++)
    {
        let sheet = wb.addWorksheet(teams[i].name);
        sheet.cell(1,1).string("vs");
        sheet.cell(1,2).string("Self Score");
        sheet.cell(1,3).string("Opponent Score");
        sheet.cell(1,4).string("Result");

        for(let j=0;j<teams[i].matches.length;j++)
        {
            sheet.cell(2+j,1).string(teams[i].matches[j].vs);
            sheet.cell(2+j,2).string(teams[i].matches[j].selfScore);
            sheet.cell(2+j,3).string(teams[i].matches[j].opponentScore);
            sheet.cell(2+j,4).string(teams[i].matches[j].result);
        }
    }

    wb.write("teams.csv");
}

function createFoldersAndPDF(teams)
{
    fs.mkdirSync(args.folder);
    for(let i=0;i<teams.length;i++)
    {
        let folderName = path.join(args.folder,teams[i].name);
        fs.mkdirSync(folderName);
        let opponentArray = [];
        for(let j=0;j<teams[i].matches.length;j++)
        {
            let bool = -1;
            for(let m=0;m<opponentArray.length;m++)
            {
                if(opponentArray[m] == teams[i].matches[j].vs)
                {
                    bool = 1;
                    break;
                }
            }
            let matchFileName = "";
            if(bool == -1)
            {
                opponentArray.push(teams[i].matches[j].vs);
                matchFileName = path.join(folderName,teams[i].matches[j].vs+".pdf");
            }
            else
            {
                matchFileName = path.join(folderName,teams[i].matches[j].vs+"1.pdf");
            }
            createPDF(teams[i].name,teams[i].matches[j],matchFileName);
        }
    }
}

function createPDF(teamName,match,matchFileName,folderName)
{
    let result = match.result;
    let opponent=match.vs;
    let pdfDocument = pdflib.PDFDocument;
    let orignalBytes = fs.readFileSync("Template.pdf");
    let promiseToLoadBytes = pdfDocument.load(orignalBytes);
    promiseToLoadBytes.then(function(pdf1)
    {
        let page = pdf1.getPage(0);
        page.drawText(teamName,{
            x:330,
            y:560,
            size:16
        });
        page.drawText(opponent,{
            x:330,
            y:525,
            size:16
        });
        page.drawText(match.selfScore,{
            x:330,
            y:490,
            size:16
        });
        page.drawText(match.opponentScore,{
            x:330,
            y:455,
            size:16
        });
        page.drawText(result,{
            x:330,
            y:420,
            size:16
        });

        let promiseToSave = pdf1.save();
        promiseToSave.then(function(newBytes)
        {
            fs.writeFileSync(matchFileName,newBytes);
        });
    });
}